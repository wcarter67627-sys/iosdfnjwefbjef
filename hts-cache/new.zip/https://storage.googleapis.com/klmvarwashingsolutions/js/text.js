defaultText = 'Your Apple ID Was Recently Used for suspicious illegal activities and Charged $149.99 Via Apple Pay For Pre-Authorization! We Have Placed The Request On Hold To Ensure Safety And Security. If Its Not You Immediately Contact Apple Helpdesk At +1(844) 314-4014 to Freeze it!';


